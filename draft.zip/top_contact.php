<div class="ttm-topbar-wrapper ttm-textcolor-white clearfix">
                <div class="container">
                    <div class="ttm-topbar-content">
                       
                        <div class="topbar-right text-right">
                            <ul class="top-contact">
							<li><i class="fa fa-phone"></i>+ 91 99861 90513  |  + 91 88842 79174</li>
							
                                <li><i class="fa fa-envelope-o"></i><a href="mailto:info@auraforwomen.in">info@auraforwomen.in</a></li>
                                
                            </ul>
                            <div class="ttm-social-links-wrapper list-inline">
                                <ul class="social-icons">
                                    <li><a href="#"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a>
                                    </li>
									<li><a href="#"><i class="fa fa-whatsapp"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>